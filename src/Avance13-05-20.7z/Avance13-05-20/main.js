import pokeData from './data/pokemon/pokemon.js';
import { allPoke, orderDataAz, orderDataZa, orderDataNumDes,  filterPokemonType, searchPokemon, weaknessFilter } from './data.js';

//Búsqueda interna (header) 

const formulario = document.getElementById("formulario");
formulario.addEventListener('keydown', function() {
    if (event.which === 15 || event.keycode === 15 || event.key === "Enter") {
        event.preventDefault();
        const busqueda = formulario.value.toLowerCase();
        const namePokemon = busqueda.toLowerCase();
        let pickPokemon = searchPokemon(dataPokedex, namePokemon);
        lookPokedex(pickPokemon);
    }
});



// del html

const card = document.getElementById("lookPoke");
//Arreglo para llamar a la data de pokémon
const dataPokedex = allPoke(pokeData.pokemon);
const orderPokeAz = orderDataAz(allPoke);
const orderPokeZa = orderDataZa(allPoke);
const orderPokeNumDes = orderDataNumDes(allPoke);

//Muestra tarjetas de pokémon en pantalla
function lookPokedex(dataInfo) {
    let cardDesign = "";
    for (let i = 0; i < dataInfo.length; i++) {
        cardDesign += `
        <div class="elemCard">
        <div id='pokemon${dataInfo[i].id}' class="card${dataInfo[i].type[0]}">
           <div class='pokeProperty'> 
               <img class="imgPokemon" src="${dataInfo[i].img}"/>
               <h2>${dataInfo[i].name}</h2>
               <h3># ${dataInfo[i].num}</h3>
               <h3>${dataInfo[i].type[0]}</h3>
           </div>
       </div>
       </div>`;
    }
    card.innerHTML = cardDesign;
}
lookPokedex(dataPokedex);



//Para ordenar alfabéticamente (a-z / z-a)
const menuPokedex = document.querySelector("#order");
menuPokedex.addEventListener("change", () => {
    const resultado = '$ {event.target.value}';
    if (resultado === "A-Z") {
        lookPokedex(orderPokeAz);
    }
    if (resultado === "Z-A") {
        lookPokedex(orderPokeZa);
    }
    if (resultado === "9-0") {
        lookPokedex(orderPokeNumDes);
    } else if (resultado === "0-9") {
    }
});


//Para filtrar por debilidad (eliminamos tipo "Normal" por no ser debilidad de ningún pokémon)
const selectorPokeWeakness = document.querySelector("#weakness");
selectorPokeWeakness.addEventListener("change", () => {
    let pokemonWeakness = selectorPokeWeakness.value;
    if (pokemonWeakness === "weakness") {
        lookPokedex(dataPokedex);
    } else {
        let result = weaknessFilter(dataPokedex, pokemonWeakness);
        lookPokedex(result);
    }
});





//Filtrar por tipo
const selectorPokeType = document.querySelector("#pokemonTypes");
selectorPokeType.addEventListener("change", () => {
    let pokemonFilterType = selectorPokeType.value;
    if (pokemonFilterType === "allType") {
        lookPokedex(dataPokedex);
    } else {
        let resultType = filterPokemonType(dataPokedex, pokemonFilterType);
        lookPokedex(resultType);
    }
});




//Modal ultra genial
function lookModal(m) {
    let modal = document.getElementById("myModal"); //Modal general html
    let modalContainer = document.getElementById("modalContent"); //Modal cuadrito blanco html
    let imgBtn = document.getElementsByClassName("elemCard"); //imagen que actua como boton. Ingresada en el js
    modal.style.display = "none"; //Para esconder el modal general al cargar la página

    for (let i = 0; i < imgBtn.length; i++) { //recorremos el for de las imagenes que creamos
        let card1 = imgBtn[i]; //guardamos cada imagen en una variable con posición i

        card1.addEventListener('click', () => { //agregamos el evento a la imagen
            console.log("ok");
            modal.style.display = "block"; //al hacer click traemos el modal general
            modalContainer.style.display = "block";
            modalContainer.innerHTML += ` 
            <div class="frame">
                <div class="x">
                    <span class="close">&times;</span>
                </div>
                <div  class="modalCharacters">
                <div class="cardElem2">
                   <h3>${m[i].num}</h3>
                   <img src="${m[i].img}"/> 
                    <h2>${m[i].name}</h2>
               </div>
                    <div class="characterInformation">
                    <p>Peso: ${m[i].weight}</p>
                    <p>Altura: ${m[i].height}</p>
                    <p>Huevo: ${m[i].egg}</p>
                    </div>
                    <div class="characterInformation2">
                        <h1>Tipo: ${m[i].type[0]}</h1>
                        
                        <p>Debilidad: ${m[i].weaknesses}</p>
                        <h1>Evolución / Caramelos:</h1>
                        <p> Pre Evolución: ${m[i].prev_evolution ? m[i].prev_evolution[0].num : ''}  ${m[i].prev_evolution ? m[i].prev_evolution[0].name : 'No tiene'}</p> 
                        <p>Caramelo: ${m[i].candy}</p>
                        <p>Caramelo: ${m[i].candy_count}</p>
                        <p> Evolución: ${m[i].next_evolution ? m[i].next_evolution[0].num : ''}  ${m[i].next_evolution ? m[i].next_evolution[0].name : 'No tiene'}</p> 
                    </div>
                </div>
            </div>`;

            let span = document.getElementsByClassName("close")[0]; // al momento de cerrar, hace este evento/
            span.addEventListener('click', () => { //evento del click en la x
                modal.style.display = "none"; //Escondemos el modal general
                modalContainer.innerHTML = "";  //Limpiamos el modal con la informacion (cuadrito blanco)
            });
        });

        window.onclick = function (event) { //evento para que al hacer click fuera del modal se cierre
            if (event.target == modal) {
                modal.style.display = "none";
                modalContainer.innerHTML = "";
            }
        }
    }
};
lookModal (dataPokedex); 


//boton logo
document.getElementById("LogoP").addEventListener("click", ()=>{
    document.getElementById("origin").style.display="block";
    document.getElementById("novato").style.display="none";
    document.getElementById("entrenador").style.display="none";
    document.getElementById("pokedexKanto").style.display="none";
    document.getElementById("pokedexKanto").style.display="none";
    document.getElementById("typePokemon").style.display="none";
    lookModal(dataPokedex);
  });
  


//Boton del menu (Entrenador)
document.getElementById("allPokemonMenu").addEventListener("click", allPokemonMenu);

function allPokemonMenu() {
    let originActual = document.getElementById("origin");
    originActual.style.display = "none";
    let lookPokedex = document.getElementById("pokedexKanto");
    lookPokedex.style.display = "block";
}
document.getElementById("typeMenu").addEventListener("click", typeMenu);

function typeMenu() {
    let originActual = document.getElementById("origin");
    originActual.style.display = "none";
    let lookType = document.getElementById("typePokemon");
    lookType.style.display = "block";
}
//Parte de los botones 
//Muestra sección Novato

document.getElementById("buttonNovato").addEventListener("click", buttonNovato);

function buttonNovato() {
    let originActual = document.getElementById("origin");
    originActual.style.display = "none";
    let lookNovato = document.getElementById("novato");
    lookNovato.style.display = "block";
}

let mostrarNovato = () => {
    document.getElementById("origin").style.display = "none";
    document.getElementById("queEsUnPokemon").style.display = "";
    document.getElementById("queEsUnPokedex").style.display = "";
    document.getElementById("queEsUnTipoDePokemon").style.display = "";
};
document.getElementById("buttonNovato").addEventListener("click", mostrarNovato);


//Muestra sección Entrenador
document.getElementById("buttonEntrenador").addEventListener("click", buttonEntrenador);

function buttonEntrenador() {
    let originActual = document.getElementById("origin");
    originActual.style.display = "none";
    let lookEntrenador = document.getElementById("entrenador");
    lookEntrenador.style.display = "block";
}

//Muestra sección Tipos de Pokémon
document.getElementById("typePokeBtn").addEventListener("click", typePokeBtn);

function typePokeBtn() {
    let entrenadorActual = document.getElementById("entrenador");
    entrenadorActual.style.display = "none";
    let lookTypePokemon = document.getElementById("typePokemon");
    lookTypePokemon.style.display = "block";
}
//Muestra sección Pokédex Kanto
document.getElementById("allPokeBtn").addEventListener("click", allPokeBtn);

function allPokeBtn() {
    let entrenadorActual = document.getElementById("entrenador");
    entrenadorActual.style.display = "none";
    let lookPokemon = document.getElementById("pokedexKanto");
    lookPokemon.style.display = "block";
}